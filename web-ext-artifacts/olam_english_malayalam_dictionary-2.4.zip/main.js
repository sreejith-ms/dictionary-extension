$(document).ready(function() {
  $("#search").submit(function() {
    var q = escape(
      $("#q")
        .val()
        .replace(/[^a-z0-9\+\-\s]/gi, "")
        .replace(/\s+/g, " ")
    );
    if (!q) return false;

    loading(true);

    $.getJSON("https://olam.in/Dictionary/en_ml/" + q + "?json=1", function(
      data
    ) {
      loading(false);
      render(q, data);
    });
    return false;
  });

  function loading(show) {
    show ? $("#loading").show() : $("#loading").hide();
  }

  function render(q, data) {
    if (!data || data.length < 1) {
      $("#results").html(
        'നിങ്ങള്‍ അന്വേഷിച്ച "' +
          q +
          '" എന്ന പദത്തിന്റെ അര്‍ഥം കണ്ടെത്താനായില്ല. സാധ്യമെങ്കില്‍, ദയവായി <a href="http://olam.in/Add/" target="_blank">നിഘണ്ടുവില്‍ ചേര്‍ക്കുക.</a>'
      );
      return;
    }
    addItem(q, data);
    var html = "";
    $(data).each(function() {
      html += "<li>";
      html += "<h2>" + this.word + '</h2><ul class="definitions">';

      $(this.definitions).each(function() {
        html += "<li>" + this + "</li>";
      });

      html += "</ul></li>";
    });

    $("#results").html(html);
  }

  $("#q").focus();

  //check for support
  if (!("indexedDB" in window)) {
    console.log("This browser doesn't support IndexedDB");
    return;
  }

  var db;
  var openRequest = indexedDB.open("olam_idb", 1);

  openRequest.onupgradeneeded = function(e) {
    var db = e.target.result;
    console.log("running onupgradeneeded");
    if (!db.objectStoreNames.contains("queries")) {
      var storeOS = db.createObjectStore("queries", { keyPath: "word" });
    }
  };

  openRequest.onsuccess = function(e) {
    console.log("running onsuccess");
    db = e.target.result;
  };

  openRequest.onerror = function(e) {
    console.log("onerror!");
    console.dir(e);
  };

  function addItem(query, results) {
    var transaction = db.transaction(["queries"], "readwrite");
    var store = transaction.objectStore("queries");
    var existingItem = store.get(query);

    existingItem.onsuccess = e => {
      var date = new Date().getTime();
      var item;
      if (!existingItem.result) {
        item = {
          word: query,
          definition: results,
          ts: [date],
          occurance: 1
        };
      } else {
        existingItem.result.ts.push(date);
        existingItem.result.occurance += 1;
        item = existingItem.result;
      }

      var request = store.put(item);

      request.onerror = e => {
        console.log("Error", e.target.error.name);
      };

      request.onsuccess = e => {
        console.log("Woot! Did it");
      };
    };

    existingItem.onerror = e => {
      console.log("Error", e.target.error.name);
    };
  }
});
